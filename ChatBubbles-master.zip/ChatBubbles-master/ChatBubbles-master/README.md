ChatBubbles
===========

This .NET 4.5 C# WPF project shows messages in a chat bubble style, like whatsapp. Ideal for interfacing with A.I. (in combination with NLP, like the great wit.ai (https://wit.ai) (see my other project, SharpWit) or building desktop chat applications.

Based on the work of Colin Eberhardt (http://tinyurl.com/ncbxxqk), converted to WPF, added uniform spacing between messages and several other tweaks.

No license, feel free to use (or ask questions about it).
