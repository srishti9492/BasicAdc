﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BusinessLoanApp.UI.Models
{
    public class Contract
    {
        public int ContractId { get; set; }
        public int borrowerProfileId { get; set; }
        public string Description { get; set; }
    }
}