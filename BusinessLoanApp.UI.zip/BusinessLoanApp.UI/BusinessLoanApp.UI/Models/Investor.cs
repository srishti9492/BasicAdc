﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BusinessLoanApp.UI.Models
{
    public class Investor
    {
        public int InvestorId { get; set; }
        public string Description { get; set; }
        public string Industry { get; set; }
        public string CreditRating { get; set; }
        public string Price { get; set; }
        public string Quantity { get; set; }
        public bool IsBuy { get; set; }
        public bool IsSell { get; set; }
    }
}