﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BusinessLoanApp.UI.Models
{
    public class Funding
    {
        public int FundId { get; set; }
        public int OfferId { get; set; }
        public int TokenId { get; set; }
        public int SyndycateId { get; set; }
        public string Description { get; set; }
    }

    public class Offer
    {
        public int OfferId { get; set; }
        public string OfferAmount { get; set; }
        public string Description { get; set; }
    }

    public class Tokens
    {
        public int TokenId { get; set; }
        public string Description { get; set; }
    }

    public class Syndycate
    {
        public int SyndycateId { get; set; }
        public string Description { get; set; }
    }
}