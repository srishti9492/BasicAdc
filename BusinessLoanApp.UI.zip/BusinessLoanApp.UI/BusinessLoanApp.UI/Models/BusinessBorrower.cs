﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BusinessLoanApp.UI.Models
{
    public class BusinessBorrower
    {
        public int ID { get; set; }
        public string UserName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string PostalCode { get; set; }
        public string LinkedInUrl { get; set; }
        public string FacebookUrl { get; set; }
        public string Twitter { get; set; }
        public string BusinessUrl1 { get; set; }
        public string BusinessUrl2 { get; set; }
        public string BlogUrl { get; set; }
        public string EkycLink { get; set; }
        public string Reference { get; set; }
        public string Patent { get; set; }
    }

    public class BorrowerProfileReview
    {
        public int BorrowerProfileId { get; set; }
        public string Summary { get; set; }
        public string Score { get; set; }
        public string Review { get; set; }
    }

    public class BorrowerBusinessPlan
    {
        public int BusinessPlanId { get; set; }
        public int BorrowerProfileId { get; set; }
        public string MarketSegment { get; set; }
        public string IndustrySegment { get; set; }
        public string PotentialClient { get; set; }
        public string Causes { get; set; }
        public string RateOffered { get; set; }
        public string Plans { get; set; }
        public string Description { get; set; }
    }

    public class BusinessPlanReview
    {
        public int BusinessPlanId { get; set; }
        public int BorrowerProfileId { get; set; }
        public string Summary { get; set; }
        public string Score { get; set; }
        public string Review { get; set; }
    }
}