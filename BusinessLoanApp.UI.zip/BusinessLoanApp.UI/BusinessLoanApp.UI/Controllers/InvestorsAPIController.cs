﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BusinessLoanApp.UI.Models;

namespace BusinessLoanApp.UI.Controllers
{
    public class InvestorsAPIController : ApiController
    {
        [HttpGet]
        [ActionName("BuyToken")]
        [Route("api/InvestorsAPI/BuyToken")]
        public IHttpActionResult BuyToken(Investor investor)
        {
            /*if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //return CreatedAtRoute("CustomApi", new { id = investor.InvestorId }, investor);
            return Ok(investor);*/
            return Ok();
        }

        [HttpGet]
        [ActionName("SellToken")]
        [Route("api/InvestorsAPI/SellToken")]
        public IHttpActionResult SellToken(Investor investor)
        {
            /*if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //return CreatedAtRoute("CustomApi", new { id = investor.InvestorId }, investor);
            return Ok(investor);*/
            return Ok();
        }
    }
}
