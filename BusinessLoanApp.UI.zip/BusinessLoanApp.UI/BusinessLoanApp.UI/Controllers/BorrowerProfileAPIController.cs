﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BusinessLoanApp.UI.Models;

namespace BusinessLoanApp.UI.Controllers
{
    public class BorrowerProfileAPIController : ApiController
    {
        private List<BusinessBorrower> enterprenures = new List<BusinessBorrower> {
            new BusinessBorrower { ID = 1, UserName = "aroger", Address = "Street1", City="San Jose", State = "California", Country = "USA", LinkedInUrl = "aroger@linkedin.com", BusinessUrl1 = "aroger@business1.com", PostalCode ="111222"},
            new BusinessBorrower { ID = 2, UserName = "lucyb", Address = "Street2", City="Charlotte", State = "North Carolina", Country = "USA", LinkedInUrl = "lucyb@linkedin.com", BusinessUrl1 = "lucyb@business1.com", PostalCode ="111222"},
            new BusinessBorrower { ID = 3, UserName = "robcumming", Address = "Street3", City="New York", State = "New York", Country = "USA", LinkedInUrl = "robc@linkedin.com", BusinessUrl1 = "robc@business1.com", PostalCode ="111222"}
        };

        [HttpGet]
        [ActionName("AllBorrowersProfile")]
        public IHttpActionResult Get()
        {
            //return enterprenures;
            return Ok();
        }

        [HttpGet]
        [ActionName("BorrowerProfileById")]
        public IHttpActionResult Get(int id)
        {
            /*var enterprenure = enterprenures.FirstOrDefault((p) => p.ID == id);
            if (enterprenure == null)
            {
                return NotFound();
            }*/
            return Ok();
        }

        [HttpPost]
        [ActionName("CreateBorrowerProfile")]
        public string Post(BusinessBorrower borrower)
        {
            if (!ModelState.IsValid)
            {
                //return BadRequest(ModelState);
            }
            //return CreatedAtRoute("DefaultApi", new { id = borrower.ID }, borrower);
            return "Borrower has been added successfully";
        }

        [HttpGet]
        [ActionName("EvaluateBorrowerProfile")]
        public IHttpActionResult Get(string borrowerId)
        {
            /*IList<BorrowerProfileReview> profiles = new List<BorrowerProfileReview>();
            var reviewProfile = profiles.FirstOrDefault((p) => p.BorrowerProfileId == (borrowerId);
            if (reviewProfile == null)
            {
                return NotFound();
            }
            return reviewProfile;*/
            return Ok();
        }
    }
}
