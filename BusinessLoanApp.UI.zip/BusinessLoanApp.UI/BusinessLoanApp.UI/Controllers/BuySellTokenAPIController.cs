﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BusinessLoanApp.UI.Models;

namespace BusinessLoanApp.UI.Controllers
{
    public class BuySellTokenAPIController : ApiController
    {
        //[Route("api/ContractAPI/GetContract")]
        [HttpGet]
        [ActionName("ContractById")]
        public IHttpActionResult Get(int id)
        {
            /*var contract = contracts.FirstOrDefault((p) => p.ContractId == id);
            if (contract == null)
            {
                return NotFound();
            }
            return Ok(contract);*/
            return Ok();
        }

        //[Route("api/ContractAPI/CreateContract")]
        [HttpPost]
        [ActionName("CreateContract")]
        public string Post(Contract contract)
        {
            /*if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            return CreatedAtRoute("DefaultApi", new { id = contract.ContractId }, contract);*/
            return "Contract has been created successfully!";
        }

        //[Route("api/ContractAPI/FinalizeContract")]
        [HttpPost]
        [ActionName("FinalizeContract")]
        public IHttpActionResult Post(int id)
        {
            /*var contract = contracts.FirstOrDefault((p) => p.ContractId == id);
            if (contract == null)
            {
                return NotFound();
            }
            return Ok(contract);*/
            return Ok();
        }
    }
}
