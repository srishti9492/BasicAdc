﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BusinessLoanApp.UI.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult BusinessPromoter()
        {
            return View();
        }

        public ActionResult BusinessPromoterHeaderLess()
        {
            return View();
        }

        public ActionResult CreateBusinessPlan()
        {
            return View();
        }

        public ActionResult CreateBusinessPlanHeaderLess()
        {
            return View();
        }

        public ActionResult Investor()
        {
            return View();
        }

        public ActionResult InvestorsHeaderLess()
        {
            return View();
        }

        public ActionResult Banker()
        {
            return View();
        }

        public ActionResult BusinessBorrowerContractDetails()
        {
            return View();
        }

        public ActionResult EntreeCatalystHome()
        {
            return View();
        }

        public ActionResult EntreeCatalystLanding()
        {
            return View();
        }

        public ActionResult AboutPlatform()
        {
            return View();
        }

        public ActionResult BusinessBenefits()
        {
            return View();
        }

        public ActionResult Architecture()
        {
            return View();
        }

        public ActionResult CognitiveAgents()
        {
            return View();
        }

        public ActionResult InvestorLogin()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }
    }
}