﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BusinessLoanApp.UI.Models;

namespace BusinessLoanApp.UI.Controllers
{
    public class FundingAPIController : ApiController
    {
        // POST: api/FundingAPI  
        [HttpPost]
        //[ActionName("CreateOffer")]
        //[Route("api/FundingAPIAPI/CreateOffer")]
        public IHttpActionResult Post(Offer offer)
        {
            /*if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            return CreatedAtRoute("DefaultApi", new { id = offer.OfferId }, offer);*/
            return Ok();
        }

        [HttpPost]
        [ActionName("CreateTokens")]
        public IHttpActionResult Post(Tokens token)
        {
            /*if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            return CreatedAtRoute("DefaultApi", new { id = token.TokenId }, token);*/
            return Ok();
        }

        [HttpPost]
        [ActionName("CreateSyndycate")]
        public IHttpActionResult Post(Syndycate syndycate)
        {
            /*if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            return CreatedAtRoute("DefaultApi", new { id = syndycate.SyndycateId }, syndycate);*/
            return Ok();
        }
    }
}
