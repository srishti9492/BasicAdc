﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace DotNet_ADC.UControls.UCDesignPipeline
{
    /// <summary>
    /// Interaction logic for UC_PipelineDesign.xaml
    /// </summary>
    public partial class UC_PipelineDesign : UserControl
    {
        ExeConfigurationFileMap configMap = new ExeConfigurationFileMap();
        static string CurrentAssemblyPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
        static string SolutionDllName = System.IO.Path.GetFileName(CurrentAssemblyPath);
        static string configuration = CurrentAssemblyPath.Replace(@"\" + SolutionDllName, @"\App.config");

        static string XmlPath = string.Empty;
        static string XmlDirPath = string.Empty;

        public UC_PipelineDesign()
        {
            InitializeComponent();
        }

        private void SetAppSettingsValues()
        {
            try
            {
                configMap.ExeConfigFilename = configuration;
                System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenMappedExeConfiguration(configMap, ConfigurationUserLevel.None);
                XmlPath = config.AppSettings.Settings["XmlPath"].Value;
                XmlDirPath = config.AppSettings.Settings["XmlDirPath"].Value;
            }
            catch (Exception ex)
            {
                throw ex;
                // ErrorLogging.LogException(ex, apiLogFilePath);
            }

        }

        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            SetAppSettingsValues();
            if (File.Exists(XmlPath))
            {
                generateXML();
            }
            else if (!File.Exists(XmlPath))
            {
                if (!System.IO.Directory.Exists(XmlDirPath))
                {
                    System.IO.Directory.CreateDirectory(XmlDirPath);
                    generateXML();
                }
                else
                {
                    generateXML();
                }
            }
        }

        private void generateXML()
        {
            ObservableCollection<PipelineData> colItems;
            //colItems = SampleData.GetInstance().TreeCollection2;
            colItems = MainViewModel.GetInstance().MSPCollection3;
            if (colItems.Count == 0)
            {
                MessageBox.Show("Please select data to create configuration file.");
            }
            else
            {
                XElement root = new XElement("PipelineStage");
                foreach (var item in colItems)
                {
                    var xml = new XElement("PipelineElement",
                              new XAttribute("Name", item.Name)
                              //new XElement("Children", item.Children.Select(x => new XElement("item", x)))
                              );
                    root.Add(xml);
                }
                root.Save(XmlPath);
                var selectedItem = cmbConfiguration.Text;
                if (selectedItem == "Select Pipeline")
                {
                    selectedItem = "Jenkins";
                }
                MessageBox.Show(selectedItem + " configuration file has been generated and saved successfully at location : " + XmlPath);
            }
        }
    }
}
