﻿using System.Collections.ObjectModel;

namespace DotNet_ADC.UControls.UCDesignPipeline
{
    public class SampleData
    {
        //Used if Default Drop Handler not used
        private static SampleData _this;

        public SampleData()
        {
            var root1 = new TreeNode($"STAGES");
            root1.Children.Add(new TreeNode($"Stage"));
            this.TreeCollection1.Add(root1);

            var root2 = new TreeNode($"PREDEFINED JOBS");
            root2.Children.Add(new TreeNode($"Compile (MSBuild)"));
            root2.Children.Add(new TreeNode($"Static Code Analysis (MSBuild)"));
            root2.Children.Add(new TreeNode($"Unit Test (TDD)"));
            root2.Children.Add(new TreeNode($"Deploy (IIS)"));
            root2.Children.Add(new TreeNode($"Docker Image Creation"));
            root2.Children.Add(new TreeNode($"Docker Push"));
            this.TreeCollection1.Add(root2);

            var root3 = new TreeNode($"CUSTOM JOBS");
            root3.Children.Add(new TreeNode($"MSBuild Job"));
            //root3.Children.Add(new TreeNode($"Maven Job"));
            root3.Children.Add(new TreeNode($"Docker Job"));
            //root3.Children.Add(new TreeNode($"CF Job"));
            root3.Children.Add(new TreeNode($"Shell Job"));
            this.TreeCollection1.Add(root3);
            

            CheckBoxList.Add(new Chk {Content = "Namespace (Using) location Rule" });
            CheckBoxList.Add(new Chk { Content = "Sort Using Rule" });
            CheckBoxList.Add(new Chk { Content = "New Line above" });
            CheckBoxList.Add(new Chk { Content = "Copyright Header Rule" });
            CheckBoxList.Add(new Chk { Content = "Mark Read Only Fields Rule" });
            CheckBoxList.Add(new Chk { Content = "Remove Unused Symbol" });
            CheckBoxList.Add(new Chk { Content = "Remove Unused Parameter" });
            CheckBoxList.Add(new Chk { Content = "Use Curly Brace for Control Statement Rule" });
            CheckBoxList.Add(new Chk { Content = "Remove Unused Using/Imports" });
            CheckBoxList.Add(new Chk { Content = "Qualify Static Member Accesses Through Subtypes With Declaring Class Rule" });
            CheckBoxList.Add(new Chk { Content = "Remove Redundant Type Arguments Rule" });
            CheckBoxList.Add(new Chk { Content = "Remove Unused Imports Rule" });
            CheckBoxList.Add(new Chk { Content = "Use Lambda Rule" });
            CheckBoxList.Add(new Chk { Content = "Always Use Blocks Rule" });
            CheckBoxList.Add(new Chk { Content = "Use This For Non Static Field Access Only If Necessary Rule" });
            CheckBoxList.Add(new Chk { Content = "Add Missing Annotations Rule" });
            CheckBoxList.Add(new Chk { Content = "Remove private Constructors Rule" });


            //Used if Default Drop Handler not used

            _this = this;

        }

        //Used if Default Drop Handler not used
        public static SampleData GetInstance()
        {
            return _this;
        }

        public ObservableCollection<TreeNode> TreeCollection1 { get; set; } = new ObservableCollection<TreeNode>();
        public ObservableCollection<TreeNode> TreeCollection2 { get; set; } = new ObservableCollection<TreeNode>();
        public static ObservableCollection<TreeNode> TreeCollectionRobo { get; set; } = new ObservableCollection<TreeNode>();

        public  void updateCollection(ObservableCollection<TreeNode>  Collection)
        {
            TreeCollectionRobo = Collection;
        }

        public ObservableCollection<Chk> CheckBoxList { get; set; } = new ObservableCollection<Chk>();

    }

    public class Chk
    {
        public string Content { get; set; }
    }
}