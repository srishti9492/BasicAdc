﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GongSolutions.Wpf.DragDrop;
using System.Windows;
using System.Collections.ObjectModel;
using System.Collections;

namespace DotNet_ADC.UControls.UCDesignPipeline
{
    public class MainViewModel : ViewModelBase, IDropTarget
    {
        private SampleData _data;

        public SampleData Data
        {
            get { return _data; }
            set
            {
                if (Equals(value, _data)) return;
                _data = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<PipelineData> MSPCollection1 { get; set; }
        public ObservableCollection<PipelineData> MSPCollection2 { get; set; }
        public ObservableCollection<PipelineData> MSPCollection3 { get; set; }
        private static MainViewModel _this;

        private ObservableCollection<TreeNode> _treeCollection2;

        public ObservableCollection<TreeNode> TreeCollection2
        {
            get { return _treeCollection2; }
            set
            {
                _treeCollection2 = value;
            }
        }

        public static MainViewModel GetInstance()
        {
            return _this;
        }

        public MainViewModel()
        {
            this.Data = new SampleData();
            _this = this;

            MSPCollection1 = new ObservableCollection<PipelineData>();
            MSPCollection2 = new ObservableCollection<PipelineData>();
            MSPCollection3 = new ObservableCollection<PipelineData>();

            MSPCollection1.Add(new PipelineData()
            {
                Id = 1,
                Name = "Compile (MSBuild)",
                // CanAcceptChildren = true,
                IsDropped = false
            });

            MSPCollection1.Add(new PipelineData()
            {
                Id = 2,
                Name = "Static Code Analysis (MSBuild)",
                // CanAcceptChildren = false,
                IsDropped = false
            });

            MSPCollection1.Add(new PipelineData()
            {
                Id = 3,
                Name = "Unit Test (TDD)",
                // CanAcceptChildren = false,
                IsDropped = false
            });

            MSPCollection1.Add(new PipelineData()
            {
                Id = 4,
                Name = "Deploy (IIS)",
                // CanAcceptChildren = false,
                IsDropped = false
            });

            MSPCollection1.Add(new PipelineData()
            {
                Id = 5,
                Name = "Docker Image Creation",
                // CanAcceptChildren = false,
                IsDropped = false
            });

            MSPCollection1.Add(new PipelineData()
            {
                Id = 6,
                Name = "Docker Push",
                //CanAcceptChildren = false,
                IsDropped = false
            });

            MSPCollection2.Add(new PipelineData()
            {
                Id = 7,
                Name = "MSBuild Job",
                //CanAcceptChildren = false,
                IsDropped = false
            });

            MSPCollection2.Add(new PipelineData()
            {
                Id = 8,
                Name = "Docker Job",
                // CanAcceptChildren = false,
                IsDropped = false
            });

            MSPCollection2.Add(new PipelineData()
            {
                Id = 9,
                Name = "Shell Job",
                //CanAcceptChildren = false,
                IsDropped = false
            });
        }

        void IDropTarget.DragOver(IDropInfo dropInfo)
        {
            PipelineData sourceItem = dropInfo.Data as PipelineData;
            PipelineData targetItem = dropInfo.TargetItem as PipelineData;
            if (sourceItem != null && targetItem == null /*&& sourceItem.CanAcceptChildren*/ && sourceItem.IsDropped == false)
            {
                dropInfo.DropTargetAdorner = DropTargetAdorners.Highlight;
                dropInfo.Effects = DragDropEffects.Copy;
                sourceItem.IsDropped = true;
            }
            if (sourceItem != null && targetItem == null /*&& sourceItem.CanAcceptChildren==false*/)
            {
                dropInfo.DropTargetAdorner = DropTargetAdorners.Highlight;
                dropInfo.Effects = DragDropEffects.Copy;
                sourceItem.IsDropped = true;
            }
            if (sourceItem != null && targetItem != null /*&& targetItem.CanAcceptChildren*/  && sourceItem.IsDropped)
            {
                dropInfo.DropTargetAdorner = DropTargetAdorners.Highlight;
                dropInfo.Effects = DragDropEffects.Move;
            }
        }

        void IDropTarget.Drop(IDropInfo dropInfo)
        {
            PipelineData sourceItem = dropInfo.Data as PipelineData;
            PipelineData targetItem = dropInfo.TargetItem as PipelineData;
            var q = MSPCollection3.Where(X => X.IsDropped == true).FirstOrDefault();
            if (q == null)
            {
                MSPCollection3.Add(new PipelineData()
                {
                    Id = sourceItem.Id,
                    Name = sourceItem.Name,
                    IsDropped = sourceItem.IsDropped
                });
            }
            else if (q.IsDropped)
            {
                MSPCollection3.Add(new PipelineData()
                {
                    Id = sourceItem.Id,
                    Name = sourceItem.Name,
                    IsDropped = sourceItem.IsDropped
                });
                if (q.IsDropped)
                {
                    MSPCollection3.Remove(sourceItem);
                }
            }
            //targetItem.Name = sourceItem.Name;
            //((IList)dropInfo.DragInfo.SourceCollection).Remove(msp);
        }

        private ObservableCollection<TreeNode> _treeCollectionRobo;

        public ObservableCollection<TreeNode> TreeCollectionRobo
        {
            get { return _treeCollectionRobo; }
            set
            {
                _treeCollectionRobo = value;
            }
        }
    }


    /*Changed*/
    //public class MainViewModel : ViewModelBase, IDropTarget
    //{
    //    private SampleData _data;
    //    private static MainViewModel _this;

    //    /// <summary>
    //    /// Initializes a new instance of the MainViewModel class.
    //    /// </summary>
    //    public MainViewModel()
    //    {
    //        this.Data = new SampleData();
    //       _this = this;
    //    }

    //    public static MainViewModel GetInstance()
    //    {
    //        return _this;
    //    }
    //    public SampleData Data
    //    {
    //        get { return _data; }
    //        set
    //        {
    //            if (Equals(value, _data)) return;
    //            _data = value;
    //            OnPropertyChanged();
    //        }
    //    }

    //    private ObservableCollection<TreeNode> _treeCollection2;

    //    public ObservableCollection<TreeNode> TreeCollection2
    //    {
    //        get { return _treeCollection2; }
    //        set
    //        {
    //            _treeCollection2 = value;
    //        }
    //    }

    //    private ObservableCollection<TreeNode> _treeCollectionRobo;

    //    public ObservableCollection<TreeNode> TreeCollectionRobo
    //    {
    //        get { return _treeCollectionRobo; }
    //        set
    //        {
    //            _treeCollectionRobo = value;
    //        }
    //    }

    //    public void DragOver(IDropInfo dropInfo)
    //    {
    //        TreeNode sourceItem = dropInfo.Data as TreeNode;
    //        TreeNode targetItem = dropInfo.TargetItem as TreeNode;
    //        dropInfo.DropTargetAdorner = DropTargetAdorners.Highlight;
    //        if (sourceItem.Caption == "Stage")
    //        {
    //            dropInfo.Effects = DragDropEffects.Move;
    //        }
    //        else
    //            dropInfo.Effects = DragDropEffects.Copy;
    //    }

    //    public void Drop(IDropInfo dropInfo)
    //    {
    //        TreeNode sourceItem = dropInfo.Data as TreeNode;
    //        TreeNode targetItem = dropInfo.TargetItem as TreeNode;

    //        //Creates new Stage
    //        if (sourceItem.Caption == "Stage" && sourceItem.Children.Count == 0 && sourceItem.IsCloned == false)
    //        {
    //            var root1 = new TreeNode($"Stage");
    //            root1.IsCloned = true;
    //            //root1.Children.Add(new TreeNode(""));
    //            Data.TreeCollection2.Add(root1);
    //        }

    //        //Used for reordering
    //        else if (sourceItem.Caption == "Stage" && sourceItem.Children.Count == 0 && sourceItem.IsCloned == true)
    //        {
    //            if (targetItem == null)
    //            {
    //                targetItem = new TreeNode();
    //                targetItem.Caption = null;
    //                targetItem.Children = null;
    //            }
    //            targetItem.Caption = sourceItem.Caption;
    //            targetItem.Children = sourceItem.Children;
    //            ((IList)dropInfo.DragInfo.SourceCollection).Add(targetItem);
    //            ((IList)dropInfo.DragInfo.SourceCollection).Remove(sourceItem);
    //        }

    //        //Used for reordering
    //        else if (sourceItem.Caption == "Stage" && sourceItem.Children.Count != 0)
    //        {
    //            if (targetItem == null)
    //            {
    //                targetItem = new TreeNode();
    //                targetItem.Caption = null;
    //                targetItem.Children = null;
    //            }
    //            targetItem.Caption = sourceItem.Caption;
    //            targetItem.Children = sourceItem.Children;
    //            ((IList)dropInfo.DragInfo.SourceCollection).Add(targetItem);
    //            ((IList)dropInfo.DragInfo.SourceCollection).Remove(sourceItem);
    //        }
    //        else
    //            MessageBox.Show("A JOB can only be dropped inside a STAGE!");

    //        this.TreeCollection2 = Data.TreeCollection2;
    //    }
    //}
}
