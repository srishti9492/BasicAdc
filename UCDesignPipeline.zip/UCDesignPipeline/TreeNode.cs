﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNet_ADC.UControls.UCDesignPipeline
{
    public class TreeNode : INotifyPropertyChanged, ICloneable
    {
        public TreeNode()
        {

        }

        TreeNode _parent;

        private string _caption;
        private ObservableCollection<TreeNode> _children;
        private bool _isCloned;
        private bool _isExpanded;
        bool? _isChecked = false;

        public TreeNode(string caption)
        {
            this.Caption = caption;
            this.Children = new ObservableCollection<TreeNode>();
        }

        public string Caption
        {
            get { return _caption; }
            set
            {
                if (value == _caption) return;
                _caption = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<TreeNode> Children
        {
            get { return _children; }
            set
            {
                if (Equals(value, _children)) return;
                _children = value;
                OnPropertyChanged();
            }
        }

        public bool IsCloned
        {
            get { return _isCloned; }
            set
            {
                if (value == _isCloned) return;
                _isCloned = value;
                OnPropertyChanged();
            }
        }

        public bool IsExpanded
        {
            get { return _isExpanded; }
            set
            {
                if (value == _isExpanded) return;
                _isExpanded = value;
                OnPropertyChanged();
            }
        }

        public bool IsInitiallySelected { get; private set; }

        public bool? IsChecked
        {
            get { return _isChecked; }
            set { this.SetIsChecked(value, true, true); }
        }

        void Initialize()
        {
            foreach (TreeNode child in this.Children)
            {
                child._parent = this;
                child.Initialize();
            }
        }

        void SetIsChecked(bool? value, bool updateChildren, bool updateParent)
        {
            if (value == _isChecked)
                return;

            _isChecked = value;

            if (updateChildren && _isChecked.HasValue)
                this.Children.ToList().ForEach(c => c.SetIsChecked(_isChecked, true, false));

            if (updateParent && _parent != null)
                _parent.VerifyCheckState();

            this.OnPropertyChanged("IsChecked");
        }

        void VerifyCheckState()
        {
            bool? state = null;
            for (int i = 0; i < this.Children.Count; ++i)
            {
                bool? current = this.Children[i].IsChecked;
                if (i == 0)
                {
                    state = current;
                }
                else if (state != current)
                {
                    state = null;
                    break;
                }
            }
            this.SetIsChecked(state, false, true);
        }
        public override string ToString()
        {
            return this.Caption;
        }

        public object Clone()
        {
            var treeNode = new TreeNode(this.Caption) { IsCloned = true };
            foreach (var child in this.Children)
            {
                treeNode.Children.Add((TreeNode)child.Clone());
            }
            return treeNode;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
