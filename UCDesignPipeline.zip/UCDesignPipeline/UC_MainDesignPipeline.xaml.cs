﻿using MahApps.Metro.Controls;
using System.Windows;
using System.Windows.Controls;

namespace DotNet_ADC.UControls.UCDesignPipeline
{
    /// <summary>
    /// Interaction logic for UC_MainDesignPipeline.xaml
    /// </summary>
    public partial class UC_MainDesignPipeline : UserControl
    {
        public UC_MainDesignPipeline()
        {
            InitializeComponent();
        }

        private void ButtonBase_OnClick(object sender, RoutedEventArgs e)
        {
            Window parentWindow = Window.GetWindow(this);
            object obj = parentWindow.FindName("myFlyout");
            Flyout flyout = (Flyout)obj;
            flyout.Content = new UCFlyoutItems();
            flyout.IsOpen = !flyout.IsOpen;
        }
    }
}
