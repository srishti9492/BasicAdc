﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DotNet_ADC.UControls.UCDesignPipeline;
using Newtonsoft.Json;
using System.Net;
using MahApps.Metro.Controls;
using System.ComponentModel;
using EnvDTE;

namespace DotNet_ADC.FAQ
{  
    /// <summary>
    /// Interaction logic for RoboWin.xaml
    /// </summary>
    public partial class FAQWin : MetroWindow
    {
        private BackgroundWorker backgroundWorker;

        public FAQWin()
        {
            InitializeComponent();
            backgroundWorker = (BackgroundWorker)this.Resources["backgroundWorker"];
            this.txtBoxQues.Focus();
            this.txtBoxQues.CaretBrush = null;
        }

        private void btnAnswer_Click(object sender, RoutedEventArgs e)
        {
            var query = txtBoxQues.Text.ToString();
            if (query == "")
            {
                this.txtSample.Visibility = Visibility.Visible;
                MessageBox.Show("Please ask a question!");
            }
            else
            {
                backgroundWorker.RunWorkerAsync(query);
                progressRingBuild.IsActive = backgroundWorker.IsBusy;
                this.btnAnswer.Visibility = Visibility.Hidden;
            }
        }

        private void btnClr_Click(object sender, RoutedEventArgs e)
        {
            ClearFormData();
        }
        
        private void ClearFormData()
        {
            progressRingBuild.IsActive = false;
            txtBoxAnswer.Document.Blocks.Clear();
            this.btnAnswer.Visibility = Visibility.Visible;
            this.lblAnswer.Visibility = Visibility.Hidden;
            this.txtBoxQues.Clear();
            this.txtBoxAnswer.Visibility = Visibility.Hidden;
            this.btnClr.Visibility = Visibility.Hidden;
            this.btnAnswer.Visibility = Visibility.Visible;
            this.txtSample.Visibility = Visibility.Visible;
            //
            this.txtBoxQues.IsEnabled = true;
            this.txtBoxQues.Focusable = true;
            this.txtBoxQues.CaretBrush = null;
            this.txtBoxQues.Focus();
            this.txtBoxQues.IsReadOnly = false;
            this.txtBoxQues.SetValue(TextBoxHelper.WatermarkProperty, "Type your question here..");
        }

        private void txtBoxQues_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                if (this.txtBoxQues.CaretBrush != null)
                {
                    ClearFormData();
                }
                else
                {
                    var query = txtBoxQues.Text.ToString();
                    if (query == "")
                    {
                        this.txtSample.Visibility = Visibility.Visible;
                        MessageBox.Show("Please ask a question!");
                    }
                    else
                    {
                        txtBoxAnswer.Document.Blocks.Clear();
                        this.lblAnswer.Visibility = Visibility.Hidden;
                        backgroundWorker.RunWorkerAsync(query);
                        progressRingBuild.IsActive = backgroundWorker.IsBusy;
                        this.btnAnswer.Visibility = Visibility.Hidden;
                        e.Handled = true;
                    }
                }
            }
        }

        private void backgroundWork_DoWork(object sender, DoWorkEventArgs e)
        {
            var query = e.Argument;
            string responseString = string.Empty;
            try
            {
                var knowledgebaseId = "e0de3499-e9b0-4576-b27e-4c8e240153ba";
                var qnamakerSubscriptionKey = "f5f9eed11a034420a5de51c744ca976b";

                Uri qnamakerUriBase = new Uri("https://westus.api.cognitive.microsoft.com/qnamaker/v1.0");
                var builder = new UriBuilder($"{qnamakerUriBase}/knowledgebases/{knowledgebaseId}/generateAnswer");

                var postBody = $"{{\"question\": \"{query}\"}}";

                //Send the POST request
                using (WebClient client = new WebClient())
                {
                    //Set the encoding to UTF8
                    client.Encoding = System.Text.Encoding.UTF8;
                    //Add the subscription key header
                    client.Headers.Add("Ocp-Apim-Subscription-Key", qnamakerSubscriptionKey);
                    client.Headers.Add("Content-Type", "application/json");
                    responseString = client.UploadString(builder.Uri, postBody);
                }
                QnAMakerResult response;
                response = JsonConvert.DeserializeObject<QnAMakerResult>(responseString);
                e.Result = response.Answer;
            }
            catch
            {
                MessageBox.Show("Error while processing your request.");
                //throw new Exception("Error while processing your request.");
            }
        }

        private void backgroundWork_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            var response = e.Result.ToString();
            progressRingBuild.IsActive = false;
            this.txtBoxAnswer.Visibility = Visibility.Visible;
            FlowDocument doc = new FlowDocument();
            {
                doc.Blocks.Add(new Paragraph(new Run(response.ToString())));
            }
            txtBoxAnswer.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            txtBoxAnswer.Document = doc;
            this.btnClr.Visibility = Visibility.Visible;
            this.btnAnswer.Visibility = Visibility.Hidden;
            this.txtSample.Visibility = Visibility.Hidden;
            this.lblAnswer.Visibility = Visibility.Visible;
            this.txtBoxQues.CaretBrush = new SolidColorBrush(Color.FromArgb(0, 0, 0, 0));
            this.txtBoxQues.Focus();
            this.txtBoxQues.IsReadOnly = backgroundWorker.IsBusy;
            //
            this.txtBoxQues.IsEnabled= backgroundWorker.IsBusy;
            this.txtBoxQues.SetValue(TextBoxHelper.WatermarkProperty, "Your Question :");
        }
    }
}
