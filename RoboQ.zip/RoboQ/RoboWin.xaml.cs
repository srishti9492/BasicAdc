﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DotNet_ADC.UControls.UCDesignPipeline;
using MahApps.Metro.Controls;
using System.Configuration;
using DotNet_ADC.Helper;

namespace DotNet_ADC.RoboQ
{
    /// <summary>
    /// Interaction logic for RoboWin.xaml
    /// </summary>
    public partial class RoboWin : MetroWindow
    {
        private string selectedCS;
        private string selectedRules;
        private string RoboQExePath = string.Empty;
        private string solutionPath = string.Empty;
        //  private ObservableCollection<TreeNode> treeCollectionRobo;

        public RoboWin(string solPath)
        {
            InitializeComponent();
            this.DataContext = new MainViewModel();
            SetRoboQPath();
            solutionPath = solPath;
        }

        private void ButtonRun_Click(object sender, RoutedEventArgs e)
        {
            //string selectedRules=null;

            RecurseItems(SampleData.TreeCollectionRobo, 0);

            if (!string.IsNullOrEmpty(selectedCS) && !string.IsNullOrEmpty(selectedRules))
            {
                selectedCS = (selectedCS.Trim()).Remove(selectedCS.Length - 2);
                selectedRules = (selectedRules.Trim()).Remove(selectedRules.Length - 2);
            }

            //DTE dte = GetCurrentDTE();
            string lsolutionPath = solutionPath;
            if (!string.IsNullOrEmpty(lsolutionPath))
            {
                //SetRoboQPath();
                ClsRunRoboQ objRoboQ = new ClsRunRoboQ();
                if (!string.IsNullOrEmpty(RoboQExePath))
                {
                    int result = objRoboQ.RunRoboQ(RoboQExePath, lsolutionPath);
                }
                else
                {
                    MessageBox.Show("Please give appropiate RoboQ EXE path in app.config");
                }
            }
            else
            {
                MessageBox.Show("Current Active Solution path is empty");
            }

            /*MessageBox.Show(selectedCS);
            MessageBox.Show(selectedRules);
            selectedCS = String.Empty;
            selectedRules = String.Empty;
            this.Close();*/

        }

        void RecurseItems(ObservableCollection<TreeNode> items, int level)
        {
            foreach (var item in items)
            {
                if (item.IsChecked == true && item.Caption.EndsWith(".cs"))
                {
                    selectedCS = selectedCS + item.Caption + ", ";
                }
                RecurseItems(item.Children, level + 1);
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox chkZone = (CheckBox)sender;
            selectedRules = selectedRules + chkZone.Content + ", ";
        }

        private void SetRoboQPath()
        {
            ExeConfigurationFileMap configMap = new ExeConfigurationFileMap();
            string CurrentAssemblyPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string SolutionDllName = System.IO.Path.GetFileName(CurrentAssemblyPath);
            string configuration = CurrentAssemblyPath.Replace(@"\" + SolutionDllName, @"\App.config");

            configMap.ExeConfigFilename = configuration;
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenMappedExeConfiguration(configMap, ConfigurationUserLevel.None);
            RoboQExePath = config.AppSettings.Settings["RoboQExePath"].Value;
        }

        //public RoboWin(ObservableCollection<TreeNode> treeCollectionRobo)
        //{
        //    this.treeCollectionRobo = treeCollectionRobo;
        //    foreach(var item in treeCollectionRobo)
        //    {
        //        TreeViewItem treeNode = new TreeViewItem();
        //        treeNode.Header = item.Caption;
        //        var count = item.Children.Count;
        //        while (count != 0)
        //        {
        //            treeNode.ItemsSource = item.Children;
        //            count--;
        //        }
        //        tree.Items.Add(treeNode);
        //    }

        //new TreeViewItem(treeCollectionRobo);
        //tree.Items.Add(new TreeviewtreeCollectionRobo);
        // }
    }
}
