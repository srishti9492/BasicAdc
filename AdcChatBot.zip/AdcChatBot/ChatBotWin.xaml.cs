﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.IO;
using System.IO.Compression;
using Microsoft.Build.Evaluation;
using DotNet_ADC.UControls.UCWebAPI;
using System.ComponentModel;
using System.Xml;
using System.Text;
using System.Configuration;
using MahApps.Metro.Controls;
using System.Text.RegularExpressions;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using DotNet_ADC.UControls.GenerateProject;
using LibGit2Sharp;
using EnvDTE80;

namespace DotNet_ADC.AdcChatBot
{
    /// <summary>
    /// Interaction logic for ChatBotWin.xaml
    /// </summary>
    public partial class ChatBotWin : MetroWindow
    {
        public MessageCollection messages = new MessageCollection();
        private Storyboard scrollViewerStoryboard;
        private DoubleAnimation scrollViewerScrollToEndAnim;
        private string QuestionTemplatesXmlFile = string.Empty;
        private MessageSide curside;
        private int quesCount = 0;
        private bool IsAspWebApp;
        private bool IsWebApi;
        private string solutionName;
        private List<string> SelectedTemplates = new List<string>();
        public bool IsRegistered;

        //configMap.ExeConfigFilename = configuration;
        private string GitRepoURL = string.Empty;
        private string TemplatePath = string.Empty;
        private string TargetPath = string.Empty;
        private string ProjectTemplatesXmlFile = string.Empty;
        private string ProjectCompletedMessage = string.Empty;
        private string AuthorName = string.Empty;
        private string AuthorMail = string.Empty;

        static string AppBuilderOutput = string.Empty;
        //static DirectoryInfo localWorkingFolder;
        static string SolutionName = string.Empty;
        private static string _repoSource;
        private static UsernamePasswordCredentials _credentials;
        private static DirectoryInfo _localFolder;
        private static BackgroundWorker backgroundWorker;
        static LoadingScreen splash;

        #region LoadFromConfigFile
        ExeConfigurationFileMap configMap = new ExeConfigurationFileMap();
        static string CurrentAssemblyPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
        static string SolutionDllName = System.IO.Path.GetFileName(CurrentAssemblyPath);
        static string configuration = CurrentAssemblyPath.Replace(@"\" + SolutionDllName, @"\App.config");
        #endregion

        #region VerticalOffset DP
        /// <summary>
        /// VerticalOffset, a private DP used to animate the scrollviewer
        /// </summary>
        private static DependencyProperty VerticalOffsetProperty = DependencyProperty.Register("VerticalOffset",
        typeof(double), typeof(ChatBotWin), new PropertyMetadata(0.0, OnVerticalOffsetChanged));
        //public double VerticalOffset
        //{
        //    get { return (double)GetValue(VerticalOffsetProperty); }
        //    set { SetValue(VerticalOffsetProperty, value); }
        //}
        //// Using a DependencyProperty as the backing store for VerticalOffset.  This enables animation, styling, binding, etc...
        //public static DependencyProperty VerticalOffsetProperty =
        //    DependencyProperty.Register("VerticalOffset", typeof(double), typeof(ChatBotWin), new PropertyMetadata(0.0, OnVerticalOffsetChanged));

        private static void OnVerticalOffsetChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ChatBotWin app = d as ChatBotWin;
            app.OnVerticalOffsetChanged(e);
        }

        private void OnVerticalOffsetChanged(DependencyPropertyChangedEventArgs e)
        {
            ConversationScrollViewer.ScrollToVerticalOffset((double)e.NewValue);
        }
        #endregion

        public ChatBotWin()
        {
            InitializeComponent();
            IntializeBackgroundWorker();
            splash = new LoadingScreen();
            // FOLLOWING CODEBLOCK IS ONLY FOR DEMONSTRATION PURPOSES
            messages.Add(new Message()
            {
                Side = MessageSide.You,
                //Text = "Hello! Welcome to .Net ADC Developer Workbench." + "\n" + "We are here to help you to generate solutions. Please select proper option from the following:"
                //+ "\n" + "1. Asp .Net Web Application"
                //+ "\n" + "2. Web API"
                //+ "\n" + "3. Rapid Code"
                //+ "\n" + "4. Service Fabric"
                Text = "Hello! Welcome to .Net ADC Developer Workbench." 
            });

            curside = MessageSide.You;
            // END OF DEMO BLOCK

            this.DataContext = messages;

            scrollViewerScrollToEndAnim = new DoubleAnimation()
            {
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new SineEase()
            };
            Storyboard.SetTarget(scrollViewerScrollToEndAnim, this);
            Storyboard.SetTargetProperty(scrollViewerScrollToEndAnim, new PropertyPath(VerticalOffsetProperty));

            scrollViewerStoryboard = new Storyboard();
            scrollViewerStoryboard.Children.Add(scrollViewerScrollToEndAnim);
            this.Resources.Add("foo", scrollViewerStoryboard);

            TextInput.Focus();
            /*call to load from xml file*/
            SetAppSettingsValues();
        }

        private void TextInput_GotFocus(object sender, RoutedEventArgs e)
        {
            ScrollConversationToEnd();
        }

        private void ScrollConversationToEnd()
        {
            scrollViewerScrollToEndAnim.From = ConversationScrollViewer.VerticalOffset;
            scrollViewerScrollToEndAnim.To = ConversationContentContainer.ActualHeight;
            scrollViewerStoryboard.Begin();
        }

        private void TextInput_LostFocus(object sender, RoutedEventArgs e)
        {
            ScrollConversationToEnd();
        }

        private void TextInput_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                addTextMe(TextInput.Text);

                e.Handled = true;
            }
        }
        
        private void addTextMe(string text)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(QuestionTemplatesXmlFile);
            string messageText = string.Empty;
            if (text.Equals("hi", StringComparison.InvariantCultureIgnoreCase)|| text.Equals("hello", StringComparison.InvariantCultureIgnoreCase))
            {
                messageText = "Hey there! Welcome to .Net ADC Developer Workbench." + "\n" + "We are here to help you to generate solutions.";
                populateMessage(text, messageText);
            }

            else if (text == "1" && quesCount == 0 || text == "2" && quesCount == 0)
            {
                XmlNodeList itemNodes = xmlDoc.SelectNodes("//ADCQuestionRepos");
                foreach (XmlNode itemNode1 in itemNodes)
                {
                    XmlNode outerNode = itemNode1.SelectSingleNode("solutionName");
                    messageText = outerNode.InnerText;
                }
                populateMessage(text, messageText);
                quesCount = quesCount + 1;

                if (text == "1")
                {
                    IsAspWebApp = true;
                }
                else if (text == "2")
                {
                    IsWebApi = true;
                }
            }

            else if (!String.IsNullOrWhiteSpace(text) && quesCount == 1 && IsAspWebApp)
            {
                XmlNodeList itemNodes = xmlDoc.SelectNodes("//ADCQuestionRepos/aspFeaturesList");
                foreach (XmlNode itemNode1 in itemNodes)
                {
                    foreach (XmlNode itemNode2 in itemNode1)
                    {
                        messageText += itemNode2.InnerText + "\n";
                    }
                }
                solutionName = text;
                messageText = messageText.Trim();
                populateMessage(text, messageText);
                quesCount = quesCount + 1;
            }

            else if (!String.IsNullOrWhiteSpace(text) && quesCount == 1 && IsWebApi)
            {
                XmlNodeList itemNodes = xmlDoc.SelectNodes("//ADCQuestionRepos/webApiFeaturesList");
                foreach (XmlNode itemNode1 in itemNodes)
                {
                    foreach (XmlNode itemNode2 in itemNode1)
                    {
                        messageText += itemNode2.InnerText + "\n";
                    }
                }
                solutionName = text;
                messageText = messageText.Trim();
                populateMessage(text, messageText);
                quesCount = quesCount + 1;
            }

            else if (Regex.IsMatch(text, @"^\d+(\d+)?(,\d+(\d+)?)*$") && quesCount == 2)
            {
                string[] values = text.Split(',');
                if (IsAspWebApp)
                {
                    for (int i = 0; i < values.Length; i++)
                    {
                        values[i] = values[i].Trim();
                        if (values[i] == "1")
                        {
                            SelectedTemplates.Add("Authentication");
                        }
                        else if (values[i] == "2")
                        {
                            SelectedTemplates.Add("Logger");
                        }
                        else if (values[i] == "3")
                        {
                            SelectedTemplates.Add("EntityFramework");
                        }
                        else if (values[i] == "4")
                        {

                        }
                        else if (values[i] == "5")
                        {
                            SelectedTemplates.Add("NUnit");
                        }
                        else
                        {
                            messageText = "Please enter valid comma separated values from the above list.";
                            populateMessage(text, messageText);
                            return;
                        }
                    }
                }
                else if (IsWebApi)
                {
                    for (int i = 0; i < values.Length; i++)
                    {
                        values[i] = values[i].Trim();
                        if (values[i] == "1")
                        {

                        }
                        else if (values[i] == "2")
                        {

                        }
                        else if (values[i] == "3")
                        {

                        }
                        else if (values[i] == "4")
                        {

                        }
                        else if (values[i] == "5")
                        {

                        }
                        else if (values[i] == "6")
                        {

                        }
                        else
                        {
                            messageText = "Please enter valid comma separated values from the above list.";
                            populateMessage(text, messageText);
                            return;
                        }
                    }
                }
                XmlNodeList itemNodes = xmlDoc.SelectNodes("//ADCQuestionRepos/confirmationMessage");
                foreach (XmlNode itemNode1 in itemNodes)
                {
                    foreach (XmlNode itemNode2 in itemNode1)
                    {
                        messageText += itemNode2.InnerText + "\n";
                    }
                }
                messageText = messageText.Trim();
                populateMessage(text, messageText);
                quesCount = quesCount + 1;
            }

            else if (!Regex.IsMatch(text, @"^\d+(\d+)?(,\d+(\d+)?)*$") && quesCount == 2 && IsAspWebApp && text != "")
            {
                messageText = "Please enter a valid comma separated value.";
                populateMessage(text, messageText);
            }

            else if (text == "1" && quesCount == 3 && IsAspWebApp || text == "1" && quesCount == 3 && IsWebApi)
            {
                messageText = "Thank you for using .Net ADC tool.";
                quesCount = quesCount + 1;
                populateMessage(text, messageText);
                btnGenerate_Click();
                IsAspWebApp = false;
                //LoadNewInstance();
            }

            else if (text == "2" && quesCount == 3 && IsAspWebApp || text == "2" && quesCount == 3 && IsWebApi)
            {
                messageText = "You have cancelled yor current selection. Thank you for using .Net ADC tool.";
                quesCount = quesCount + 1;
                populateMessage(text, messageText);
                IsAspWebApp = false;
            }

            else if (text != "" && quesCount == 0 || text != "" && quesCount == 3)
            {
                messageText = "Please enter a valid numeric option!";
                populateMessage(text, messageText);
            }
        }

        private void LoadNewInstance()
        {
            new ChatBotWin().Show();
        }

        private void populateMessage(string text, string messageText)
        {
            messages.Add(new Message()
            {
                Side = MessageSide.Me,
                Text = text,
                PrevSide = curside
            });
            curside = MessageSide.Me;
            ScrollConversationToEnd();
            TextInput.Text = "";
            TextInput.Focus();
            addTextYou(messageText);
        }

        private void addTextYou(string text)
        {
            messages.Add(new Message()
            {
                Side = MessageSide.You,
                Text = text,
                PrevSide = curside
            });
            curside = MessageSide.You;
            ScrollConversationToEnd();
            TextInput.Text = "";
            TextInput.Focus();
        }

        private void SetAppSettingsValues()
        {
            try
            {
                configMap.ExeConfigFilename = configuration;
                System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenMappedExeConfiguration(configMap, ConfigurationUserLevel.None);
                GitRepoURL = config.AppSettings.Settings["GitRepoURL"].Value;
                TemplatePath = config.AppSettings.Settings["TemplatePath"].Value;
                TargetPath = config.AppSettings.Settings["TargetDevBotPath"].Value;
                ProjectTemplatesXmlFile = config.AppSettings.Settings["ProjectTemplatesXmlFile"].Value;
                QuestionTemplatesXmlFile = config.AppSettings.Settings["QuestionTemplatesXmlFile"].Value;
                ProjectCompletedMessage = config.AppSettings.Settings["ProjectCompletedMessage"].Value;
                AuthorName = config.AppSettings.Settings["AuthorName"].Value;
                AuthorMail = config.AppSettings.Settings["AuthorMail"].Value;
            }
            catch (Exception ex)
            {
                throw ex;
                // ErrorLogging.LogException(ex, apiLogFilePath);
            }
        }

        private void btnGenerate_Click()
        {
            try
            {
                if (!string.IsNullOrEmpty(solutionName))
                {
                    string SolutionName = solutionName;

                    #region Get Selected Plugins
                    XmlDocument ProjectTemplates = new XmlDocument();
                    ProjectTemplates.Load(ProjectTemplatesXmlFile);
                    List<string> ProjectTemplatePaths = new List<string>();
                    foreach (var item in SelectedTemplates)
                    {
                        if (ProjectTemplates.SelectSingleNode(@"//ProjectTemplates/ProjectTemplate[@Name='" + item + "']") != null)
                        {
                            ProjectTemplatePaths.Add(ProjectTemplates.SelectSingleNode(@"//ProjectTemplates/ProjectTemplate[@Name='" + item + "']").Attributes["Folder"].Value);
                        }
                    }
                    ProjectTemplatePaths.Add("ADC.WebAPI");
                    ProjectTemplatePaths.Add("ADC.ASPNET");
                    #endregion

                    List<string> ProjectTemplateAddr = new List<string>();
                    ProjectTemplateAddr = ProjectTemplatePaths;

                    InputsUser inputs = new InputsUser();
                    //if (radioFile.IsChecked == true)
                    //{
                    //    TargetPath = TxtBoxDirectory.Text;
                    //    inputs.IsFileSystem = true;
                    //}
                    //else
                    //{
                    //    inputs.IsFileSystem = false;
                    //}
                    RemoveOldDirectories();

                    inputs.SolutionName = SolutionName;
                    inputs.ProjectTemplateAddr = ProjectTemplateAddr;

                    //if (txtBlkAppBuilder.Text != "No File Choosen")
                    //{
                    //    inputs.AppBuilderPath = txtBlkAppBuilder.Text;
                    //    inputs.IsAppBuilderPath = true;
                    //}
                    //else
                    //{
                    //    inputs.IsAppBuilderPath = false;
                    //}

                    //if (!string.IsNullOrEmpty(TxtBoxEdmx.Text))
                    //{
                    //    inputs.EdmxPath = TxtBoxEdmx.Text.Trim();
                    //    inputs.IsEdmx = true;
                    //}

                    //else
                    //{
                    //    inputs.IsEdmx = false;
                    //}
                    inputs.IsAppBuilderPath = false;
                    inputs.IsEdmx = false;
                    inputs.IsFileSystem = false;
                    backgroundWorker.RunWorkerAsync(inputs);
                    this.Opacity = 0.3;
                    splash.ShowDialog();

                }
                else
                {
                    MessageBox.Show("Please Enter a Solution Name");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void IntializeBackgroundWorker()
        {
            backgroundWorker = new BackgroundWorker();
            backgroundWorker.DoWork += BackgroundWorker_DoWork;
            backgroundWorker.RunWorkerCompleted += BackgroundWorker_RunWorkerCompleted;
            backgroundWorker.WorkerReportsProgress = true;
            backgroundWorker.ProgressChanged += BackgroundWorker_ProgressChanged;
        }

        private void BackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            splash.LblLoadingDyn.Content = e.UserState.ToString();
        }

        private void BackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            splash.Hide();
            splash.LblLoadingDyn.Content = "";
            this.Opacity = 1;

            var result = MessageBox.Show(ProjectCompletedMessage + Environment.NewLine + "Time Elaspsed: " + e.Result.ToString() + " mm:ss.ff", "Result", MessageBoxButton.OK, MessageBoxImage.Information);
            //if (result == MessageBoxResult.OK && radioFile.IsChecked == false)
            //{
            //    JenkinsLoading load = new JenkinsLoading();
            //    load.logic();
            //}
        }

        private void BackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            //RemoveOldDirectories();
            BackgroundWorker worker = (BackgroundWorker)sender;

            int i = 0;

            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            InputsUser obj = (InputsUser)e.Argument;
            string SolutionName = obj.SolutionName;
            List<string> ProjectTemplateAddr = obj.ProjectTemplateAddr;
            string edmxPath = obj.EdmxPath;
            bool IsFileSystem = obj.IsFileSystem;
            Command_Login objcmd = new Command_Login();

            worker.ReportProgress(i, "Creating Solution...");
            EnvDTE.Solution Sln = objcmd.CreateSol();
            Sln.Create(TargetPath, SolutionName);

            foreach (var Project in ProjectTemplateAddr)
            {
                worker.ReportProgress(i, "Adding " + Project + "...");
                Sln.AddFromTemplate(TemplatePath + @"\" + Project + @"\Mytemplate.vstemplate", TargetPath + @"\" + Project, SolutionName + "." + Project, false);
            }

            #region Create solution for selected projects
            //  CreateSolution(SolutionName, ProjectTemplateAddr);
            #endregion

            worker.ReportProgress(i, "Copying NuGet Packages...");
            #region Copy nuget package folder to target path
            CopyFolders(TemplatePath + @"\" + "packages", TargetPath + @"\" + "packages");
            #endregion

            //EnvDTE.DTE dte = objcmd.GetDTEObj();
            // dte.ExecuteCommand("Project.UnLoad",);

            //Edmx
            if (obj.IsEdmx)
            {
                GenerateAPIModel objModel = new GenerateAPIModel();
                GenerateClasses(objModel, SolutionName, edmxPath);
            }

            if (obj.IsAppBuilderPath)
            {
                worker.ReportProgress(i, "Integrating AppBuilder to Website Project...");
                #region
                string file = obj.AppBuilderPath;
                AppBuilderOutput = string.Empty;
                string appBuilderFile = string.Empty;
                string[] testfiles = file.Split(new char[] { '\\' });
                appBuilderFile = testfiles[testfiles.Length - 1];

                // Get the complete folder path and store the file inside it.  
                // appBuilderFile = System.IO.Path.Combine(@"D:\WPF_ADC.NET\WPFUserControl\DotNet-ADC\DotNet-ADC\AppBuilder", appBuilderFile);
                /*string appBPath = Path.GetFullPath("..\\AppBuilder").Replace(@"\bin", string.Empty);
                appBuilderFile = System.IO.Path.Combine(appBPath, appBuilderFile);
                File.Copy(file, appBuilderFile, true);*/

                string appBPath = System.IO.Path.GetFullPath("..\\AppBuilder").Replace(@"\bin", string.Empty);
                appBuilderFile = System.IO.Path.Combine(appBPath, appBuilderFile);
                File.Copy(file, appBuilderFile, true);

                #endregion

                #region Integrate Appbuilder Output
                ZipFile.ExtractToDirectory(appBuilderFile, TargetPath + @"\ADC.ASPNET\AppBuilder");

                #endregion
            }

            //if (IsFileSystem == false)
            //{
            //    #region Perform Git Operations
            //    worker.ReportProgress(i, "Committing generated code to GitHub...");
            //    //PerformGitOperations();
            //    #endregion
            //}

            Sln.SaveAs(TargetPath + @"\" + SolutionName + ".sln");
            sw.Stop();
            e.Result = sw.Elapsed.ToString("mm\\:ss\\.ff");
        }

        private void RemoveOldDirectories()
        {
            if (Directory.GetDirectories(TargetPath).Length != 0)
            {
                System.IO.DirectoryInfo di = new DirectoryInfo(TargetPath);

                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    if (dir.Name != ".vs" && dir.Name != ".git")
                        dir.Delete(true);
                }
                foreach (FileInfo file in di.GetFiles())
                {
                    if (file.Name.EndsWith(".sln"))
                        file.Delete();
                }
            }
        }

        public void CreateSolution(string SolutionName, List<string> Projects)
        {
            Type VSType = Type.GetTypeFromProgID("VisualStudio.DTE.14.0");
            Object Obj = Activator.CreateInstance(VSType, false);
            DTE2 Dte80Obj = (DTE2)Obj;
            Solution2 Sln = (Solution2)Dte80Obj.Solution;
            Sln.Create(TargetPath, SolutionName);
            Sln.DTE.MainWindow.Visible = true;
            foreach (var Project in Projects)
            {
                Sln.AddFromTemplate(TemplatePath + @"\" + Project + @"\Mytemplate.vstemplate", TargetPath + @"\" + Project, SolutionName + "." + Project, false);
            }
            Sln.SaveAs(TargetPath + @"\" + SolutionName + ".sln");
            Sln.Close();
        }

        public void CopyFolders(string SourcePath, string TargetPath)
        {
            foreach (var DirPath in Directory.GetDirectories(SourcePath, "*", SearchOption.AllDirectories))
            {
                Directory.CreateDirectory(DirPath.Replace(SourcePath, TargetPath));
            }
            foreach (var NewPath in Directory.GetFiles(SourcePath, "*.*", SearchOption.AllDirectories))
            {
                System.IO.File.Copy(NewPath, NewPath.Replace(SourcePath, TargetPath), true);
            }
        }

        static void AddFolderToProject(Project ProjectObj, string Folder)
        {
            ProjectObj.AddItem("Folder", Folder);
            foreach (var file in Directory.GetFiles(Folder))
            {
                //Dictionary<string, string> metadata = new Dictionary<string, string>();
                //metadata.Add("CopyToOutputDirectory", "Always");
                // ProjectObj.AddItem("Content", file);
                var item = ProjectObj.AddItem("Content", file);
                item[0].SetMetadataValue("CopyToOutputDirectory", "Always");

            }
            foreach (var folder in Directory.GetDirectories(Folder))
            {
                AddFolderToProject(ProjectObj, folder);
            }
        }

        public void PerformGitOperations()
        {
            GitRepositoryManager("admin", "admin", GitRepoURL, TargetPath);
            CommitAllChanges("AppSwift project Committed");
            PushCommits("origin", @"refs/heads/master");
        }

        public void GitRepositoryManager(string username, string password, string gitRepoUrl, string localFolder)
        {
            var folder = new DirectoryInfo(localFolder);

            if (!folder.Exists)
            {
                throw new Exception(string.Format("Source folder '{0}' does not exist.", _localFolder));
            }
            _localFolder = folder;
            _credentials = new UsernamePasswordCredentials
            {
                Username = username,
                Password = password
            };
            _repoSource = gitRepoUrl;
        }

        /// <summary>
        /// Commits all changes.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <exception cref="System.Exception"></exception>
        public void CommitAllChanges(string message)
        {
            using (var repo = new Repository(_localFolder.FullName))
            {
                var files = _localFolder.GetFiles("*", SearchOption.AllDirectories).Select(f => f.FullName);

                // repo.Stage(files);

                LibGit2Sharp.Commands.Stage(repo, files);
                // Commands.Stage(repo, files);
                // repo.Stage(files, null);

                Signature author = new Signature(AuthorName, AuthorMail, DateTime.Now);
                Signature committer = author;

                // repo.Commit(message);
                repo.Commit(message, author, committer);
            }
        }

        public void PushCommits(string remoteName, string branchName)
        {
            using (var repo = new Repository(_localFolder.FullName))
            {
                var remote = repo.Network.Remotes.FirstOrDefault(r => r.Name == remoteName);
                if (remote == null)
                {
                    repo.Network.Remotes.Add(remoteName, _repoSource);
                    remote = repo.Network.Remotes.FirstOrDefault(r => r.Name == remoteName);
                }

                var options = new PushOptions
                {
                    CredentialsProvider = (url, usernameFromUrl, types) => _credentials
                };

                repo.Network.Push(remote, branchName, options);
            }
        }

        public void GenerateClasses(GenerateAPIModel model, string solName, string edmxPath)
        {

            string targetPath = TargetPath + @"\ADC.WebAPI\Controllers\";

            string EdmxPath = @"" + edmxPath;
            //XDocument xmlDoc = new XDocument();           
            //xmlDoc = XDocument.Load(EdmxPath);

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(EdmxPath);

            var nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
            nsmgr.AddNamespace("edmx", "http://schemas.microsoft.com/ado/2009/11/edmx");

            XmlNodeList nl = xmlDoc.SelectNodes("edmx:Edmx/edmx:Runtime/edmx:ConceptualModels", nsmgr);

            foreach (XmlNode node in nl[0].FirstChild.ChildNodes)
            {
                if (node.Name == "EntityType")
                {
                    model.EntitiesName.Add(node.Attributes["Name"].Value);
                }
            }
            //XmlNodeList nodeList = xmlDoc.SelectNodes("/edmx:Edmx/edmx:Runtime/edmx:ConceptualModels/Schema");
            //XmlNodeList xnList = xmlDoc.SelectNodes("/edmx:Edmx[@*]/edmx:Runtime/edmx:ConceptualModels");
            //var xnList =   xmlDoc.SelectNodes(@"//edmx:Edmx/edmx:Runtime/edmx:ConceptualModels/Schema/EntityType");

            foreach (string strClass in model.EntitiesName)
            {
                model.ClassName = strClass;
                string strClassBody = new GenApiTemplate(model).TransformText();
                string fileName = @"" + targetPath + model.ClassName + ".cs";

                using (FileStream fs = File.Create(fileName))
                {
                    // Add some text to file
                    Byte[] text = new UTF8Encoding(true).GetBytes(strClassBody);
                    fs.Write(text, 0, text.Length);
                }
            }

            SaveControllers(targetPath, solName);

        }

        public void SaveControllers(string targetPath, string SolutionName)
        {
            //var ProjectObj = new Project(@"D:\ADC\Athlon-Services\Athlon.Test.WebAPI\Athlon.Test.WebAPI\Athlon.Test.WebAPI.csproj");
            //var ProjectObj = new Project(TargetPath + @"\Athlon.WebAPI\" + SolutionName + @".Athlon.WebAPI.csproj");
            var ProjectObj = new Project(TargetPath + @"\ADC.WebAPI\" + SolutionName + @".ADC.WebAPI.csproj");

            foreach (var file in Directory.GetFiles(targetPath))
            {
                string fileName = System.IO.Path.GetFileName(file);
                if (fileName != "AccountController.cs" && fileName != "HomeController.cs" && fileName != "ValuesController.cs")
                {
                    if (ProjectObj.Items.FirstOrDefault(f => f.EvaluatedInclude == file) == null)
                    {
                        //p.AddItem("Build", file);
                        //p.Save();
                        var item = ProjectObj.AddItem("Content", file);
                        item[0].SetMetadataValue("CopyToOutputDirectory", "Always");
                    }
                }
            }
            ProjectObj.Save();
        }
        //private void btnAppBuilder_Click(object sender, RoutedEventArgs e)
        //{
        //    Microsoft.Win32.OpenFileDialog dlgAppBld = new Microsoft.Win32.OpenFileDialog();
        //    // Display OpenFileDialog by calling ShowDialog method
        //    Nullable<bool> result = dlgAppBld.ShowDialog();
        //    // Get the selected file name and display in a TextBox
        //    if (result == true)
        //    {
        //        // Open document
        //        txtBlkAppBuilder.Text = dlgAppBld.FileName;
        //    }
        //}

        //private void btnBDDSwift_Click(object sender, RoutedEventArgs e)
        //{
        //    Microsoft.Win32.OpenFileDialog dlgBddSwift = new Microsoft.Win32.OpenFileDialog();
        //    // Display OpenFileDialog by calling ShowDialog method
        //    Nullable<bool> result = dlgBddSwift.ShowDialog();
        //    // Get the selected file name and display in a TextBox
        //    if (result == true)
        //    {
        //        // Open document
        //        txtBlkBddSwift.Text = dlgBddSwift.FileName;
        //    }
        //}

        //private void BtnEdmx_OnClick(object sender, RoutedEventArgs e)
        //{
        //    Microsoft.Win32.OpenFileDialog dlgEdmx = new Microsoft.Win32.OpenFileDialog();
        //    // Display OpenFileDialog by calling ShowDialog method
        //    Nullable<bool> result = dlgEdmx.ShowDialog();
        //    // Get the selected file name and display in a TextBox
        //    if (result == true)
        //    {
        //        // Open document
        //        TxtBoxEdmx.Text = dlgEdmx.FileName;
        //    }
        //}

        //public List<string> GetCheckBoxValue()
        //{
        //    List<string> SelectedTemplates = new List<string>();
        //    if (chkboxLogger.IsChecked == false && chkboxNUnit.IsChecked == false && chkboxXUnit.IsChecked == false
        //             && chkboxEntityFrm.IsChecked == false && chkboxAuth.IsChecked == false && chkboxCache.IsChecked == false
        //             && chkboxDapper.IsChecked == false)
        //    {
        //        // MessageBoxResult result = MessageBox.Show("Kindly select atleast one project","Alert",MessageBoxButton.OK);
        //    }
        //    else
        //    {

        //        if (chkboxLogger.IsChecked == true)
        //        {
        //            SelectedTemplates.Add("Logger");//ADC.Logger
        //        }

        //        if (chkboxXUnit.IsChecked == true)
        //        {
        //            SelectedTemplates.Add("XUnit");//ADC.Test.XUnit
        //        }
        //        if (chkboxNUnit.IsChecked == true)
        //        {
        //            SelectedTemplates.Add("NUnit");//ADC.Test.NUnit
        //        }
        //        if (chkboxEntityFrm.IsChecked == true)
        //        {
        //            SelectedTemplates.Add("EntityFramework");//ADC.EntityFramework
        //        }
        //        //if (chkboxNHiber.IsChecked == true)
        //        //{
        //        //    SelectedTemplates.Add("NHibernate");//ADC.NHibernate
        //        //}
        //        if (chkboxAuth.IsChecked == true)
        //        {
        //            SelectedTemplates.Add("Authentication");//ADC.BasicAuthentication
        //        }

        //        if (chkboxCache.IsChecked == true)
        //        {
        //            SelectedTemplates.Add("Caching");//ADC.Caching
        //        }

        //        if (chkboxDapper.IsChecked == true)
        //        {
        //            SelectedTemplates.Add("Dapper");//ADC.Dapper
        //        }
        //        //if (chkboxLinqToSql.IsChecked == true)
        //        //{
        //        //    SelectedTemplates.Add("LINQ To SQL");//ADC.LINQToSQL
        //        //}

        //    }
        //    #region Get Selected Plugins
        //    XmlDocument ProjectTemplates = new XmlDocument();
        //    ProjectTemplates.Load(ProjectTemplatesXmlFile);
        //    List<string> ProjectTemplatePaths = new List<string>();
        //    foreach (var item in SelectedTemplates)
        //    {
        //        if (ProjectTemplates.SelectSingleNode(@"//ProjectTemplates/ProjectTemplate[@Name='" + item + "']") != null)
        //        {
        //            ProjectTemplatePaths.Add(ProjectTemplates.SelectSingleNode(@"//ProjectTemplates/ProjectTemplate[@Name='" + item + "']").Attributes["Folder"].Value);
        //        }
        //    }
        //    ProjectTemplatePaths.Add("ADC.WebAPI");
        //    ProjectTemplatePaths.Add("ADC.ASPNET");
        //    #endregion

        //    return ProjectTemplatePaths;
        //}


        //private void RBtn_Angularjs_Unchecked(object sender, RoutedEventArgs e)
        //{
        //    txtBlkAppBuilder.Text = "No File Choosen";
        //}

        //private void Btndirectory_Click(object sender, RoutedEventArgs e)
        //{
            //Microsoft.Win32.OpenFileDialog dlgdirect = new Microsoft.Win32.OpenFileDialog();
            //// Display OpenFileDialog by calling ShowDialog method
            //Nullable<bool> result = dlgdirect.ShowDialog();

            //// Get the selected file name and display in a TextBox
            //if (result == true)
            //{
            //    // Open document

            //    TxtBoxDirectory.Text = dlgdirect.FileName;
            //}
            //System.Windows.Forms.FolderBrowserDialog folderDlg = new System.Windows.Forms.FolderBrowserDialog();
            //folderDlg.ShowNewFolderButton = true;
            //// Show the FolderBrowserDialog.
            //System.Windows.Forms.DialogResult result = folderDlg.ShowDialog();
            //if (result == System.Windows.Forms.DialogResult.OK)
            //{
            //    TxtBoxDirectory.Text = folderDlg.SelectedPath;
            //    Environment.SpecialFolder root = folderDlg.RootFolder;
            //}
        //}

        //private void radioFile_Checked(object sender, RoutedEventArgs e)
        //{
        //    deployLayer.Opacity = 0.5;
        //}

        //private void radioFile_Unchecked(object sender, RoutedEventArgs e)
        //{
        //    deployLayer.Opacity = 1;
        //}

        //private void CheckBox_Checked(object sender, RoutedEventArgs e)
        //{
        //    chckExistingSolution.Visibility = Visibility.Visible;
        //    txtSolutionName.Visibility = Visibility.Hidden;
        //}

        //private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        //{
        //    chckExistingSolution.Visibility = Visibility.Hidden;
        //    txtSolutionName.Visibility = Visibility.Visible;
        //}
    }

    public class InputsUser
    {
        public string SolutionName { get; set; }
        public List<string> ProjectTemplateAddr { get; set; }
        public string AppBuilderPath { get; set; }
        public string EdmxPath { get; set; }
        public bool IsEdmx { get; set; }
        public bool IsAppBuilderPath { get; set; }
        public bool IsFileSystem { get; set; }
    }
}
