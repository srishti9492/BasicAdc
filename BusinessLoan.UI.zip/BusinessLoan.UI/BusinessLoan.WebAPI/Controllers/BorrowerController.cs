﻿using BusinessLoan.WebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace BusinessLoan.WebAPI.Controllers
{
    public class BorrowerController : ApiController
    {
        static readonly IBorrowerRepository employeeRepository = new BorrowerRepository();
        static readonly IMvcEntityRepository entityRepository = new MvcEntityRepository();

        //Get all employees

        //api/employee
        [HttpGet]
        public IEnumerable<Borrower> LoadAll()
        {
            return employeeRepository.GetAll();
        }

        [HttpGet]
        public Borrower LoadBorrower(int id)
        {
            return employeeRepository.Get(id); ;

        }

        [HttpPost]
        public MvcEntity PostToWebApi(MvcEntity employee)
        {
            return entityRepository.Add(employee);
        }

        [HttpPost]
        public Borrower AddBorrower(Borrower employee)
        {
            return employeeRepository.Add(employee);
        }

        [HttpPut]
        public Borrower EditBorrower(int id, Borrower employee)
        {
            employee.id = id;
            return employeeRepository.Update(employee);

        }

        [HttpDelete]
        public IEnumerable<Borrower> DeactivateBorrower(int id)
        {
            return employeeRepository.Delete(id);

        }

    }
}