﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BusinessLoan.WebAPI.Models
{
    public class MvcEntity
    {
        public MvcEntity()
        {

        }
        public Int32 Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}