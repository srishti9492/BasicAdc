﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLoan.WebAPI.Models
{
    interface IBorrowerRepository
    {
        IEnumerable<Borrower> GetAll();
        Borrower Get(int id);
        Borrower Add(Borrower employee);
        Borrower Update(Borrower employee);
        IEnumerable<Borrower> Delete(int id);
    }
}
