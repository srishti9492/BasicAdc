﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BusinessLoan.WebAPI.Models
{
    public class MvcEntityRepository: IMvcEntityRepository
    {
        private List<MvcEntity> entity = new List<MvcEntity>();
        private int _nextId = 1;

        public MvcEntity Add(MvcEntity entities)
        {
            if (entities == null)
            {
                throw new ArgumentNullException("Employee");
            }
            entities.Id = _nextId++;
            entity.Add(entities);
            return entities;
        }
    }
}