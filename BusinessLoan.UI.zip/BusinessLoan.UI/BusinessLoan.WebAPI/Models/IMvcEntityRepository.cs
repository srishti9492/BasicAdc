﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLoan.WebAPI.Models
{
    public interface IMvcEntityRepository
    {
        MvcEntity Add(MvcEntity entities);
    }
}

