﻿using BusinessLoan.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace BusinessLoan.UI.Controllers
{
    public class EntityController : ApiController
    {
        static readonly IEntityRepository employeeRepository = new EntityRepository();

        public EntityController()
        {

        }

        //[HttpGet]
        //public IEnumerable<Entities> CreateEntities()
        //{
        //    return employeeRepository.CreateEntities();
        //}

        [HttpGet]
        public IHttpActionResult CreateEntities()
        {
            return Ok(employeeRepository.CreateEntities());
        }

        [HttpPost]
        [ResponseType(typeof(Entities))]
        public IHttpActionResult AddNewEntities(Entities entity)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid model");
            else if (entity.FirstName==null)
            {
                return NotFound();
            }
            else
            {
                employeeRepository.Add(entity);
            }
            return Ok();
        }
    }
}
