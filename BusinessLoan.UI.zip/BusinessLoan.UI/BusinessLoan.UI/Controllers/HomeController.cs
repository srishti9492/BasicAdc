﻿using BusinessLoan.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace BusinessLoanApp.UI.Controllers
{
    public class HomeController : Controller
    {
        List<string> LstControllerActions = new List<string>();
        public HomeController()
        {
            CreateActionList();
        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult BusinessPromoter()
        {
            return View();
        }

        public ActionResult BusinessPromoterHeaderLess()
        {
            return View();
        }

        public ActionResult CreateBusinessPlan()
        {
            return View();
        }

        public ActionResult CreateBusinessPlanHeaderLess()
        {
            return View();
        }

        public ActionResult Investor()
        {
            return View();
        }

        public ActionResult InvestorsHeaderLess()
        {
            return View();
        }

        public ActionResult OtherProjectWebApi()
        {
            using (var client = new HttpClient())
            {
                var entityDetailUrl1 = new Uri("http://localhost:59575/api/Borrower/LoadAll");
                var model = client
                            .GetAsync(entityDetailUrl1)
                            .Result
                            .Content.ReadAsAsync<Borrower[]>().Result;
                return View(model);
            }
        }

        //public ActionResult BusinessBorrowerContractDetails()
        //{
        //    return View();
        //}

        public ActionResult BusinessBorrowerContractDetails()
        {
            using (var client = new HttpClient())
            {
                var entityDetailUrl1 = Url.RouteUrl(
                    "ActionApi",
                    new { httproute = "", controller = "Entity", action="CreateEntities"},
                    Request.Url.Scheme
                );
                var model = client
                            .GetAsync(entityDetailUrl1)
                            .Result
                            .Content.ReadAsAsync<Entities[]>().Result;
                return View(model);
            }
        }

        //New
        public ActionResult PostToWebApi(Entities entity)
        {
            using (var client = new HttpClient())
            {
                var entityDetailUrl1 = new Uri("http://localhost:59575/api/Borrower/PostToWebApi");
                //HTTP POST
                var postTask = client.PostAsJsonAsync<Entities>("AddNewEntities", entity);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("BusinessBorrowerContractDetails");
                }
                else
                {
                    return View(entity);
                }
            }
        }
        //public ActionResult AddEntity()
        //{
        //    return View();
        //}

        public ActionResult IISHostedJson()
        {
            IEnumerable<BusinessPromoter> students = null;
            using (var client = new HttpClient())
            {
                
                client.BaseAddress = new Uri("http://in-hyd-msadc:8090/api/businesspromoters");
                //HTTP GET
                var responseTask = client.GetAsync("businesspromoters");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<BusinessPromoter>>();
                    readTask.Wait();
                    students = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..
                    //students = Enumerable.Empty<StudentViewModel>();
                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(students);
        }

        public ActionResult AddEntity(Entities entity)
        {
            using (var client = new HttpClient())
            {
                var entityDetailUrl1 = Url.RouteUrl(
                    "ActionApi",
                    new { httproute = "", controller = "Entity", action = "AddNewEntities" },
                    Request.Url.Scheme
                );
                client.BaseAddress = new Uri(entityDetailUrl1);
                //HTTP POST
                var postTask = client.PostAsJsonAsync<Entities>("AddNewEntities", entity);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("BusinessBorrowerContractDetails");
                }
                else
                {
                    return View(entity);
                }
            }
        }

        private void CreateActionList()
        {
            // Only Action Names
            List<string> lstControllerActions = new List<string>();
            var allActionNames = from aName in Assembly.GetExecutingAssembly().GetTypes()
            .Where(type => typeof(Controller).IsAssignableFrom(type)) //filter controllers
            .SelectMany(type => type.GetMethods())
            .Where(method => method.IsPublic && method.ReturnType == typeof(ActionResult))
                                 select aName;//filter actions;

            // Controller and Action Names
            var allController = from controllers in Assembly.GetExecutingAssembly().GetTypes()
            .Where(type => typeof(Controller).IsAssignableFrom(type))
                                select controllers;
            foreach (var controller in allController)
            {
                var methods = controller.GetMethods(BindingFlags.Public | BindingFlags.Instance);
                foreach (var method in methods)
                {
                    if (method.ReturnType == typeof(ActionResult))
                    {
                        LstControllerActions.Add(string.Format("Controller -> Action : {0} -> {1}", controller.Name, method.Name));
                    }
                }
            }
        }
    }
}