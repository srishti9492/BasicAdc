﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLoan.UI.Models
{
    public interface IEntityRepository
    {
        IEnumerable<Entities> CreateEntities();
        Entities Add(Entities entities);
    }
}
