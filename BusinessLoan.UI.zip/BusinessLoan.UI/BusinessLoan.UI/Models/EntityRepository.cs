﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace BusinessLoan.UI.Models
{
    public class EntityRepository: IEntityRepository
    {
        private List<Entities> entity = new List<Entities>();
        private int _nextId = 1;
        public EntityRepository()
        {
            Add(new Entities { Id = 1, FirstName = "Michale ", LastName = "Sharma" });
            Add(new Entities { Id = 2, FirstName = "Sunil", LastName = "Das" });
            Add(new Entities { Id = 3, FirstName = "Robin ", LastName = "Pandey" });
            Add(new Entities { Id = 4, FirstName = "Mona ", LastName = "Singh" });
        }

        public IEnumerable<Entities> CreateEntities()
        {
            return entity;
        }

        public Entities Add(Entities entities)
        {
            if (entities == null)
            {
                throw new ArgumentNullException("Employee");
            }
            entities.Id = _nextId++;
            entity.Add(entities);
            return entities;
        }
    }
}