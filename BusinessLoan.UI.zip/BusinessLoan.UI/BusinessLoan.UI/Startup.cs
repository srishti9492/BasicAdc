﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(BusinessLoan.UI.Startup))]
namespace BusinessLoan.UI
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
